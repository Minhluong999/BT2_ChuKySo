# ==========================================
# tamper_pdf.py
# ==========================================
# 🎯 Mục tiêu:
#   - Làm sai lệch vùng dữ liệu được ký trong signed.pdf
#   - Không làm thay đổi kích thước file
#   - Giữ nguyên chữ ký (/Contents) để kiểm thử verify_pdf.py
# ==========================================

import re
import shutil
import os

# === Cấu hình file ===
SIGNED_FILE = "signed.pdf"
BACKUP_FILE = "signed.backup.pdf"
TAMPERED_FILE = "tampered.pdf"

# === Kiểm tra file tồn tại ===
for file in [SIGNED_FILE]:
    if not os.path.exists(file):
        raise FileNotFoundError(f"❌ Không tìm thấy file: {file}")

# === Bước 1: Tạo bản sao backup ===
shutil.copyfile(SIGNED_FILE, BACKUP_FILE)
print(f"🗂️  Đã tạo bản sao dự phòng: {BACKUP_FILE}")

# === Bước 2: Đọc dữ liệu PDF gốc ===
with open(SIGNED_FILE, "rb") as f:
    data = f.read()

# === Bước 3: Tìm vùng ByteRange ===
m = re.search(rb"/ByteRange\s*\[\s*(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s*\]", data)
if not m:
    raise SystemExit("❌ Không tìm thấy /ByteRange trong file. Hãy kiểm tra file signed.pdf.")

a, b, c, d = [int(x) for x in m.groups()]
print(f"🔍 ByteRange tìm thấy: [{a}, {b}, {c}, {d}]")

# === Bước 4: Xác định vị trí sửa trong vùng bảo vệ ===
start, end = a, a + b
pos = start + 200 if (start + 200) < end else start + 50

# Nếu vùng đầu không phù hợp, thử vùng sau
if pos >= end:
    start, end = c, c + d
    pos = start + 200 if (start + 200) < end else start + 50

if pos >= end:
    raise SystemExit("❌ Không tìm được vị trí hợp lệ để sửa trong vùng ByteRange!")

print(f"✏️  Sẽ sửa 1 byte tại offset: {pos} (nằm trong [{start}, {end}))")

# === Bước 5: Sửa 1 byte (lật bit thấp nhất để giữ nguyên kích thước) ===
ba = bytearray(data)
old_byte = ba[pos]
ba[pos] = old_byte ^ 1  # XOR 1 bit
print(f"🔧 Byte cũ: 0x{old_byte:02x}  →  Byte mới: 0x{ba[pos]:02x}")

# === Bước 6: Ghi file mới ===
with open(TAMPERED_FILE, "wb") as f:
    f.write(ba)

print(f"✅ Đã tạo file: {TAMPERED_FILE}")
print("🧪 Hãy chạy verify_pdf.py để kiểm tra – kết quả mong đợi:")
print("   ➤ Hash sai: False")
print("   ➤ Chữ ký sai: False")
print("   ➤ Certificate vẫn đúng: True")
print("=========================================")
