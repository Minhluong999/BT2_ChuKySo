# ==========================================
# verify_pdf.py
# ==========================================
# 🎯 Mục tiêu:
#   - Xác thực chữ ký số trong file PDF
#   - Kiểm tra tính toàn vẹn, hợp lệ chữ ký, chứng chỉ
#   - Ghi log ra file verify_result.txt
# ==========================================

from endesive.pdf import verify
import datetime
import os

LOG_FILE = "verify_result.txt"

def log_write(text):
    """Ghi log ra file + in ra màn hình"""
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(text + "\n")
    print(text)

def verify_pdf(pdf_path, cert_path):
    """Hàm xác minh chữ ký PDF"""
    log_write("=========================================")
    log_write(f"🔍 File kiểm tra: {pdf_path}")
    log_write(f"📜 Chứng chỉ sử dụng: {cert_path}")
    log_write(f"🕒 Thời gian xác minh: {datetime.datetime.now()}")
    
    if not os.path.exists(pdf_path):
        log_write(f"❌ Không tìm thấy file PDF: {pdf_path}")
        return
    if not os.path.exists(cert_path):
        log_write(f"❌ Không tìm thấy file chứng chỉ: {cert_path}")
        return

    with open(pdf_path, "rb") as f:
        pdf_bytes = f.read()
    with open(cert_path, "rb") as f:
        cert = f.read()

    try:
        result = verify(pdf_bytes, (cert,))
        log_write("✅ Kết quả chi tiết:")
        for key, value in result.items():
            log_write(f"   {key:<12}: {value}")
    except Exception as e:
        log_write(f"❌ Lỗi xác minh: {str(e)}")

    log_write("=========================================\n")

if __name__ == "__main__":
    # === Xóa log cũ và tạo log mới ===
    with open(LOG_FILE, "w", encoding="utf-8") as f:
        f.write("=== KẾT QUẢ KIỂM TRA CHỮ KÝ PDF ===\n")
        f.write(f"Thời gian bắt đầu: {datetime.datetime.now()}\n")
        f.write("=========================================\n")

    # === Kiểm tra các file PDF ===
    verify_pdf("signed.pdf", "luong.cer")
    verify_pdf("tampered.pdf", "luong.cer")

    log_write("✅ Quá trình kiểm tra hoàn tất.")
