# ==========================================
# verify_pdf.py
# ==========================================
# 🎯 Mục tiêu:
#   - Xác thực chữ ký số trên PDF (signed.pdf, tampered.pdf)
#   - Kiểm tra 3 tiêu chí:
#       + Hash toàn vẹn
#       + Tính hợp lệ của chữ ký
#       + Chứng chỉ xác thực
#   - Sử dụng thư viện endesive.pdf.verify
# ==========================================

from endesive.pdf import verify
import os

def verify_pdf(pdf_path, cert_path):
    """Hàm xác minh chữ ký PDF"""
    if not os.path.exists(pdf_path):
        print(f"❌ Không tìm thấy file PDF: {pdf_path}")
        return
    if not os.path.exists(cert_path):
        print(f"❌ Không tìm thấy file chứng chỉ: {cert_path}")
        return

    with open(pdf_path, "rb") as f:
        pdf_bytes = f.read()
    with open(cert_path, "rb") as f:
        cert = f.read()

    print("=========================================")
    print(f"🔍 ĐANG XÁC MINH: {os.path.basename(pdf_path)}")
    print(f"📜 Dùng chứng chỉ: {os.path.basename(cert_path)}")

    try:
        result = verify(pdf_bytes, (cert,))
        # Kết quả trả về dạng dict, ví dụ:
        # {'signature': True, 'intact': True, 'cert': True, 'signer': '...', 'date': '...'}
        print("✅ Kết quả chi tiết:")
        for key, value in result.items():
            print(f"   {key:<12}: {value}")
        print("=========================================\n")
    except Exception as e:
        print(f"❌ Lỗi xác minh {pdf_path}: {e}")
        print("=========================================\n")


if __name__ == "__main__":
    # === Đường dẫn file cần xác minh ===
    CERT_FILE = "luong.cer"  # chứng chỉ người ký

    # 1️⃣ Kiểm tra file signed.pdf (chữ ký đúng)
    verify_pdf("signed.pdf", CERT_FILE)

    # 2️⃣ Kiểm tra file tampered.pdf (đã bị chỉnh sửa)
    verify_pdf("tampered.pdf", CERT_FILE)
