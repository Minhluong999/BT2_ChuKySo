# ==========================================
# sign_pdf.py – Ký số file PDF và hiển thị chữ ký trên trang
# ==========================================
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.serialization import pkcs12
from endesive.pdf import cms
import datetime

def sign_pdf():
    # 🔐 Đọc file chứng chỉ PFX cá nhân
    with open("luong.pfx", "rb") as f:
        pfx_data = f.read()

    # ✅ Giải mã file PFX (nếu có mật khẩu thì thay "pass:" vào)
    private_key, cert, add_certs = pkcs12.load_key_and_certificates(
        pfx_data, b""
    )

    # 🕒 Lấy thời gian ký
    date = datetime.datetime.utcnow().strftime("D:%Y%m%d%H%M%S+00'00'")

    # 💾 Cấu hình thông tin chữ ký (sẽ hiện trên PDF)
    signature = {
        "sigflags": 3,
        "contact": "Lăng Nguyễn Minh Lượng",
        "location": "Trường Đại học Kỹ thuật Công nghiệp - ĐH Thái Nguyên",
        "signingdate": date,
        "reason": "Bài tập chữ ký số - Môn An toàn và bảo mật thông tin",
        "signature": "Lăng Nguyễn Minh Lượng",
        "signature_img": "signature.png",

        # Vị trí hiển thị khung chữ ký
        "sigpage": 0,               # Trang đầu tiên
        "sigbutton": True,          # Hiển thị khung
        "sigfield": "Signature1",   # Tên trường chữ ký
        "box": (380, 80, 570, 230), # (x1, y1, x2, y2)
        "text": (
            "Người ký: Lăng Nguyễn Minh Lượng\n"
            "Ngày ký: 31/10/2025\n"
            "Trường ĐH Kỹ thuật Công nghiệp - TNUT"
        ),
    }

    # 📄 Đọc file PDF gốc
    with open("original.pdf", "rb") as f:
        datau = f.read()

    # ✍️ Ký số PDF bằng SHA256 + RSA
    datas = cms.sign(datau, signature, private_key, cert, add_certs, "sha256")

    # 💾 Xuất file PDF đã ký
    with open("signed.pdf", "wb") as f:
        f.write(datau + datas)

    print("✅ Đã ký số thành công: signed.pdf (hiển thị tên và chữ ký hình ảnh)")

if __name__ == "__main__":
    sign_pdf()
