# ==========================================
# sign_pdf.py - Ky PDF khong loi hybrid xref (PyHanko 0.31.x)
# ==========================================
from datetime import datetime
from pyhanko.sign import signers, fields
from pyhanko.stamp.text import TextStampStyle
from pyhanko.pdf_utils import images
from pyhanko.pdf_utils.text import TextBoxStyle
from pyhanko.pdf_utils.layout import SimpleBoxLayoutRule, AxisAlignment, Margins
from pyhanko.sign.general import load_cert_from_pemder
from pyhanko_certvalidator import ValidationContext
from pyhanko.pdf_utils.incremental_writer import IncrementalPdfFileWriter
from pyhanko.sign.fields import SigFieldSpec
import os

# === DUONG DAN ===
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PDF_IN = os.path.join(BASE_DIR, "..", "pdf", "original.pdf")  # giu file goc
PDF_OUT = os.path.join(BASE_DIR, "..", "pdf", "signed.pdf")
KEY_FILE = os.path.join(BASE_DIR, "..", "keys", "signer_key.pem")
CERT_FILE = os.path.join(BASE_DIR, "..", "keys", "signer_cert.pem")
SIG_IMG = os.path.join(BASE_DIR, "..", "photo", "anh.png")

# === KIEM TRA FILE ===
for fpath in [PDF_IN, KEY_FILE, CERT_FILE, SIG_IMG]:
    if not os.path.exists(fpath):
        raise FileNotFoundError(f"❌ Thieu file: {fpath}")

print("📄 Dang ky PDF va chen khung chu ky...")

# === TAO SIGNER ===
signer = signers.SimpleSigner.load(KEY_FILE, CERT_FILE, key_passphrase=None)
vc = ValidationContext(trust_roots=[load_cert_from_pemder(CERT_FILE)])

# === MO FILE GOC ===
with open(PDF_IN, "rb") as inf:
    # ⚠️ FIX lỗi hybrid cross-reference (PDF 2.0)
    writer = IncrementalPdfFileWriter(inf, strict=False)
    writer._enable_hybrid_xrefs = True  # cho phép ký file hybrid PDF
    
    # Lấy số trang (nếu lỗi, mặc định = 1)
    try:
        num_pages = int(writer.root["/Pages"].get("/Count", 1))
    except Exception:
        num_pages = 1

    target_page = num_pages - 1  # Trang cuối

    # === Thêm trường chữ ký ===
    fields.append_signature_field(
        writer,
        SigFieldSpec(
            sig_field_name="SigField1",
            box=(200, 40, 560, 160),
            on_page=target_page,
        ),
    )

    # === Ảnh chữ ký tay ===
    background_img = images.PdfImage(SIG_IMG)
    bg_layout = SimpleBoxLayoutRule(
        x_align=AxisAlignment.ALIGN_MIN,
        y_align=AxisAlignment.ALIGN_MID,
        margins=Margins(right=20),
    )
    text_layout = SimpleBoxLayoutRule(
        x_align=AxisAlignment.ALIGN_MIN,
        y_align=AxisAlignment.ALIGN_MID,
        margins=Margins(left=150),
    )
    text_style = TextBoxStyle(font_size=12)

    # === Nội dung chữ ký (không dấu để hiển thị chuẩn) ===
    ngay_ky = datetime.now().strftime("%d/%m/%Y")
    stamp_text = (
        "Lang Nguyen Minh Luong"
        "\nSDT: 0982247105"
        "\nMSV: K225480106044"
        f"\nNgay ky: {ngay_ky}"
        "\nDia diem: Thai Nguyen, Viet Nam"
    )

    # === Giao diện khung chữ ký ===
    stamp_style = TextStampStyle(
        stamp_text=stamp_text,
        background=background_img,
        background_layout=bg_layout,
        inner_content_layout=text_layout,
        text_box_style=text_style,
        border_width=1,
        background_opacity=1.0,
    )

    # === Metadata chữ ký ===
    meta = signers.PdfSignatureMetadata(
        field_name="SigField1",
        reason="Nop bai: Chu ky so PDF - 58KTPM",
        location="Thai Nguyen, Viet Nam",
        md_algorithm="sha256",
    )

    # === Ký và lưu PDF ===
    pdf_signer = signers.PdfSigner(
        signature_meta=meta,
        signer=signer,
        stamp_style=stamp_style,
    )

    with open(PDF_OUT, "wb") as outf:
        pdf_signer.sign_pdf(writer, output=outf)

print("✅ Da ky PDF thanh cong!")
print("📁 File da luu tai:", PDF_OUT)
print("🖋️ File ho tro hybrid PDF (PDF 2.0) - hien thi duoc trong VS Code / Chrome.")
